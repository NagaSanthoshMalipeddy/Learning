// import static org.junit.jupiter.api.Assertions.assertEquals;

// import org.junit.jupiter.api.Test;

public class Main {
  public static void main(String[] args) throws CloneNotSupportedException {
    Shape s = new Circle("red", 6);
    System.out.println(s);
    Shape clonedCircle = s.clone();
    System.out.println(clonedCircle);
    s.initialize(3);
    System.out.println(s);
    System.out.println(clonedCircle);

    Shape s1 = new Square("blue", 1, 2);
    System.out.println(s1.clone());

  }

  // @Test
  // void addition() {
  // assertEquals(2, 1 + 1);
  // }
}