public class Square extends Shape {
  private int length;
  private int bredth;

  public Square(String color, int len, int bdth) {
    super(color);
    this.length = len;
    this.bredth = bdth;
  }

  public void initialize(int lb) {
    this.length = lb;
    this.bredth = lb;
  }

  public String toString() {
    return "Circle: color=" + getColor() + "length : " + length + " bredth : " + bredth;
  }

  public Shape clone() throws CloneNotSupportedException {
    throw new CloneNotSupportedException("We dont support clone for this class");
  }
}