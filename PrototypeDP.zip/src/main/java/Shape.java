public abstract class Shape implements Cloneable {
  private String color;

  public Shape(String color) {
    this.color = color;
  }

  public Shape clone() throws CloneNotSupportedException {
    Shape s = (Shape) super.clone();
    return s;
  }

  public String getColor() {
    return color;
  }

  public String toString() {
    return "Shape: color=" + color;
  }

  public abstract void initialize(int r);
}