public abstract class Storage{
  public String name;
  public Storage(String name){
    this.name=name;
  }
  public abstract void store();
  public abstract void retrieve();
}