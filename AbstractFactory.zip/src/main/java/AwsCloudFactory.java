public class AwsCloudFactory extends CloudFactory{
  public AwsCloudFactory(){
    System.out.println("AwsCloudFactory");
  }
  public Storage createStorage(String name){
    return new AwsStorage(name);
  }
  public Instance createInstance(String name){
    return new AwsInstance(name);
  }
}