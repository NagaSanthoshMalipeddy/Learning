public class GoogleInstance extends Instance{
  public GoogleInstance(String name){
    super(name);
  }
  public void start(){
    System.out.println("Starting instance " + name);
  }
  public void stop(){
    System.out.println("Stopping instance " + name);
  }
}