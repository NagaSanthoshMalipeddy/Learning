public class AwsStorage extends Storage{
  public AwsStorage(String name){
    super(name);
  }
  public void store(){
    System.out.println("storing.... in " + name);
  }
  public void retrieve(){
    System.out.println("retrieving from storage " + name);
  }
}