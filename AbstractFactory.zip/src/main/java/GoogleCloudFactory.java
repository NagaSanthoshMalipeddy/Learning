public class GoogleCloudFactory extends CloudFactory{
  public GoogleCloudFactory(){
    System.out.println("GoogleCloudFactory");
  }
  public Storage createStorage(String name){
    return new AwsStorage(name);
  }
  public Instance createInstance(String name){
    return new AwsInstance(name);
  }
}