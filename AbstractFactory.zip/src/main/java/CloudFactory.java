public abstract class CloudFactory {
  public abstract Storage createStorage(String name);

  public abstract Instance createInstance(String name);
}