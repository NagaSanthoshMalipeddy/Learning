public class GoogleStorage extends Storage{
  public GoogleStorage(String name){
    super(name);
  }
  public void store(){
    System.out.println("storing.... in " + name);
  }
  public void retrieve(){
    System.out.println("retrieving from storage " + name);
  }
}