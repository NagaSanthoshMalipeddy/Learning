public abstract class Instance {
  public String name;

  public Instance(String name) {
    this.name = name;
  }

  public abstract void start();

  public abstract void stop();
}