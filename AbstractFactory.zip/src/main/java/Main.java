// import static org.junit.jupiter.api.Assertions.assertEquals;

// import org.junit.jupiter.api.Test;

public class Main {
  public static void main(String[] args) {
    run(new AwsCloudFactory());
    run(new GoogleCloudFactory());
  }

  public static void run(CloudFactory factory) {
    Storage storage = factory.createStorage("test");
    storage.store();
    storage.retrieve();
    Instance instance = factory.createInstance("test");
    instance.start();
    instance.stop();
  }

  // @Test
  // void addition() {
  // assertEquals(2, 1 + 1);
  // }
}