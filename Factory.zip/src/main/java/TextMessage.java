public class TextMessage implements IMessage {
  public void printContent() {
    System.out.println("This is a text message");
  }
}