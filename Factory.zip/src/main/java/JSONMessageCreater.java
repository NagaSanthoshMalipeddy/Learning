public class JSONMessageCreater extends MessageCreater {
  public IMessage createMessage() {
    System.out.println("JSON message is creating....");
    // preprocess to create JSON message
    IMessage m = new JSONMessage();
    System.out.println("created.");
    return m;
  }
}