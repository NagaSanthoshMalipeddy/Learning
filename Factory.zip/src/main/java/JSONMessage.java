public class JSONMessage implements IMessage {

  public void printContent() {
    System.out.println("JSON mssg");
  }

}