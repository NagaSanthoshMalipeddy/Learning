public class TextMessageCreater extends MessageCreater {
  public IMessage createMessage() {
    System.out.println("Text message is creating....");
    // preprocess to create text message
    IMessage m = new TextMessage();
    System.out.println("created.");
    return m;
  }
}