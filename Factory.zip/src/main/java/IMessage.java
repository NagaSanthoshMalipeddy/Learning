public interface IMessage {
  public void printContent();
}