public abstract class MessageCreater {
  public IMessage getMessage() {
    return createMessage();
  }

  public abstract IMessage createMessage();
}