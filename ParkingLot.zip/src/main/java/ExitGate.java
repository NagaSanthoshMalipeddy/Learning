import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;

public class ExitGate {

  public void UpdateParkingSpot(Ticket t) {
    ParkingSpot p = t.getParkingSpot();
    p.setEmpty(true);
    p.setVehicle(null);
    t.setStrategy(null);
    t.setVehicle(null);
    t.setParkingSpot(null);
  }

  public int calcPrice(Ticket ticket) {
    int t = LocalTime.now().getSecond() - ticket.getTime().getSecond();
    int price = ticket.getStrategy().calcPrice(t,ticket.getParkingSpot().getPrice());
    UpdateParkingSpot(ticket);
    return price;
  }
}