import java.util.*;

public abstract class ParkingSpaceManager {
  public List<ParkingSpot> parkingSpots;
  public ParkingSpot parkingSpot;

  public ParkingSpaceManager(List<ParkingSpot> parkingSpots) {
    this.parkingSpots = parkingSpots;
  }

  public ParkingSpaceManager() {

  }

  public void addParkingSpot(List<ParkingSpot> parkingSpot) {
    parkingSpots.addAll(parkingSpot);
  }

  public void removeParkingSpot(List<ParkingSpot> parkingSpot) {
    parkingSpots.removeAll(parkingSpot);
  }

  public void updateParkingSpot(ParkingSpot parkingSpot, boolean isEmpty) {
    parkingSpot.setEmpty(isEmpty);
  }

  public ParkingSpot findEmptySpot() throws Exception {
    for (ParkingSpot spot : parkingSpots) {
      if (spot.isEmpty()) {
        updateParkingSpot(spot, false);
        return spot;
      }
    }
    throw new Exception("No empty spot found");
  }
}