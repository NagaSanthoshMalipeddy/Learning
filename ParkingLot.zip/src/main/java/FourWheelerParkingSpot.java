public class FourWheelerParkingSpot extends ParkingSpot {
  int price=20;
  public FourWheelerParkingSpot(int spotNumber, VehicleTypes parkingspotType) {
    super(spotNumber, parkingspotType);
  }
  public int getPrice() {
    return price;
  }

  public void setPrice(int price) {
    this.price = price;
  }
}