
import PriceStrategyComp.*;
public class ParkingSpaceDesign implements IParkingSpaceDesign{
  Entrance entrance = new Entrance();
  ExitGate exit = new ExitGate();
  public Ticket enter(VehicleTypes vehTypes, String vehNo, String strategy) throws Exception{
    return entrance.createTicket(vehTypes, vehNo, strategy);
  }
  public int exit(Ticket ticket){
    return exit.calcPrice(ticket);
  }
}