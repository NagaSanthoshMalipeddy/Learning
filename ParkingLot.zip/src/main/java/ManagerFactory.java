import PriceStrategyComp.*;
import java.util.*;
public class ManagerFactory {
  TwoWheelerParkingSpaceManager twpm;
  FourWheelerParkingSpaceManager fwpm;
  public ParkingSpaceManager getParkingSpaceManager(VehicleTypes vehType) throws Exception {
    if (vehType == VehicleTypes.FourWheeler) {
      return FourWheelerManager();
    } else if (vehType == VehicleTypes.TwoWheeler) {
      return TwoWheelerManager();
    }
    throw new Exception("No parking for " + vehType.toString());
  }

  public IPriceStrategy getPaymentStrategy(String paymentType) throws Exception {
    if (paymentType.equals("Hourly")) {
      return new HourlyPriceStrategy();
    } else if (paymentType.equals("Minutes")) {
      return new MinutesPriceStrategy();
    }
    throw new Exception("No such payment type founf");
  }
  private TwoWheelerParkingSpaceManager TwoWheelerManager(){
    if(twpm==null){
      ArrayList<ParkingSpot> twps = new ArrayList<ParkingSpot>();
      for(int i=0;i<100;i++){
        twps.add(new TwoWheelerParkingSpot(i,VehicleTypes.TwoWheeler));
      }
      return new TwoWheelerParkingSpaceManager(twps);
    }
    return twpm;
  }
  private FourWheelerParkingSpaceManager FourWheelerManager(){
    if(fwpm==null){
      ArrayList<ParkingSpot> fwps = new ArrayList<ParkingSpot>();
      for(int i=0;i<100;i++){
        fwps.add(new FourWheelerParkingSpot(i,VehicleTypes.TwoWheeler));
      }
      return new FourWheelerParkingSpaceManager(fwps);
    }
    return fwpm;
  }
}