import java.time.LocalTime;
import PriceStrategyComp.*;
public class Ticket {
  private LocalTime time;
  private ParkingSpot parkingSpot;
  private Vehicle vehicle;
  private IPriceStrategy strategy;

  public LocalTime getTime() {
    return time;
  }

  public void setTime(LocalTime time) {
    this.time = time;
  }

  public ParkingSpot getParkingSpot() {
    return parkingSpot;
  }

  public void setParkingSpot(ParkingSpot parkingSpot) {
    this.parkingSpot = parkingSpot;
  }

  public Vehicle getVehicle() {
    return vehicle;
  }

  public void setVehicle(Vehicle vehicle) {
    this.vehicle = vehicle;
  }

  public IPriceStrategy getStrategy() {
    return strategy;
  }

  public void setStrategy(IPriceStrategy strategy) {
    this.strategy = strategy;
  }

}