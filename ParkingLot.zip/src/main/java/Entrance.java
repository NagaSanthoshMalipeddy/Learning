import java.time.LocalTime;

public class Entrance {
  private ParkingSpaceManager parkingSpaceManager;
  ManagerFactory factory = new ManagerFactory();

  public Ticket createTicket(VehicleTypes vehType, String vehNo, String payStrategy) throws Exception{
    parkingSpaceManager = factory.getParkingSpaceManager(vehType);
    Ticket t=new Ticket();
    t.setParkingSpot(parkingSpaceManager.findEmptySpot());
    t.setVehicle(new Vehicle(vehNo, vehType));
    t.setTime(LocalTime.now());
    t.setStrategy(factory.getPaymentStrategy(payStrategy));
    return t;
  }
}