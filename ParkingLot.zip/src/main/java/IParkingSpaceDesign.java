
import PriceStrategyComp.*;
public interface IParkingSpaceDesign{
  public Ticket enter(VehicleTypes vehTypes, String vehNo, String strategy) throws Exception;
  public int exit(Ticket ticket) throws Exception;
}