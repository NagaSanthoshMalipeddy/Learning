public abstract class  ParkingSpot {
  private int spotNumber;
  private Vehicle vehicle;
  private boolean isEmpty;
  private VehicleTypes parkingspotType;
  private int price;

  public ParkingSpot(int spotNumber, VehicleTypes parkingspotType) {
    this.spotNumber = spotNumber;
    this.parkingspotType = parkingspotType;
    this.isEmpty = true;
  }

  public Vehicle getVehicle() {
    return vehicle;
  }

  public void setVehicle(Vehicle vehicle) {
    this.vehicle = vehicle;
  }

  public boolean isEmpty() {
    return isEmpty;
  }

  public void setEmpty(boolean isEmpty) {
    this.isEmpty = isEmpty;
  }

  public int getSpotNumber() {
    return spotNumber;
  }

  public void setSpotNumber(int spotNumber) {
    this.spotNumber = spotNumber;
  }

  public void setParkingspotType(VehicleTypes parkingspotType) {
    this.parkingspotType = parkingspotType;
  }

  public VehicleTypes getParkingspotType() {
    return parkingspotType;
  }

  public int getPrice() {
    return price;
  }

  public void setPrice(int price) {
    this.price = price;
  }

}