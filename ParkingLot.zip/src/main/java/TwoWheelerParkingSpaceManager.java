import java.util.*;

public class TwoWheelerParkingSpaceManager extends ParkingSpaceManager {
  public TwoWheelerParkingSpaceManager(List<ParkingSpot> parkingSpots) {
    super(parkingSpots);
  }

  public TwoWheelerParkingSpaceManager() {
  }
}