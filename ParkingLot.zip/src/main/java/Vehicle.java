public class Vehicle {
  private String VehicleNumber;
  private VehicleTypes vehicleType;

  public Vehicle(String VehicleNumber, VehicleTypes vehicleType) {
    this.VehicleNumber = VehicleNumber;
    this.vehicleType = vehicleType;
  }

  public String getVehicleNumber() {
    return VehicleNumber;
  }

  public void setVehicleNumber(String vehicleNumber) {
    VehicleNumber = vehicleNumber;
  }

  public VehicleTypes getVehicleType() {
    return vehicleType;
  }

  public void setVehicleType(VehicleTypes vehicleType) {
    this.vehicleType = vehicleType;
  }

}