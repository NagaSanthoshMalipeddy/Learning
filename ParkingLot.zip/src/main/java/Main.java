// import static org.junit.jupiter.api.Assertions.assertEquals;
import PriceStrategyComp.*;
// import org.junit.jupiter.api.Test;

public class Main {
  public static void main(String[] args) {
    try{
    IParkingSpaceDesign des = new ParkingSpaceDesign();
    Ticket t = des.enter(VehicleTypes.TwoWheeler, "AP21AQ2919", "Hourly");
    System.out.println(des.exit(t)+" is the price");
    }
    catch(Exception e){
      System.out.println(e.getMessage());
    }
  }

  // @Test
  // void addition() {
  //     assertEquals(2, 1 + 1);
  // }
}