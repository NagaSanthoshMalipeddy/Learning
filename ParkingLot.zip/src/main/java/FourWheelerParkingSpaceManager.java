import java.util.*;

public class FourWheelerParkingSpaceManager extends ParkingSpaceManager {
  public FourWheelerParkingSpaceManager(List<ParkingSpot> parkingSpots) {
    super(parkingSpots);
  }

  public FourWheelerParkingSpaceManager() {
  }

}