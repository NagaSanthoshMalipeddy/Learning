package PriceStrategyComp;

public interface IPriceStrategy {
  public int calcPrice(int hours, int price);
}