package PriceStrategyComp;

public class MinutesPriceStrategy implements IPriceStrategy {
  public int calcPrice(int min, int price) {
    return min * price;
  }
}