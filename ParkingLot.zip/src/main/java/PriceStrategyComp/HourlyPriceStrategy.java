package PriceStrategyComp;

public class HourlyPriceStrategy implements IPriceStrategy {
  public int calcPrice(int hours, int price) {
    return hours * price;
  }
}