
public enum VehicleTypes {
  TwoWheeler,
  FourWheeler
}