public class TwoWheelerParkingSpot extends ParkingSpot {
  int price=10;
  public TwoWheelerParkingSpot(int spotNumber, VehicleTypes parkingspotType) {
    super(spotNumber, parkingspotType);
  }
  public int getPrice() {
    return price;
  }

  public void setPrice(int price) {
    this.price = price;
  }
}