public class TicTacToeController {
  private TicTacToePlayArea playArea;

  public TicTacToeController(TicTacToePlayArea playArea) {
    this.playArea = playArea;
  }

  public void createBoard(int size1, int size2) {
    Shapes[][] board = new Shapes[size1][size2];
    playArea.setBoard(board);
  }

  public boolean isBoardFull() {
    Shapes[][] board = playArea.getBoard();
    for (int i = 0; i < board.length; i++) {
      for (int j = 0; j < board[i].length; j++) {
        if (board[i][j] == null) {
          return false;
        }
      }
    }
    return true;
  }

  public void displayBoard() {
    Shapes[][] board = playArea.getBoard();
    for (int i = 0; i < board.length; i++) {
      System.out.print("|");
      for (int j = 0; j < board[i].length; j++) {
        System.out.print(board[i][j] + " ");
      }
      System.out.println("|");
    }
  }

  public boolean chooseShape(int x, int y, Shapes shape) {
    Shapes[][] board = playArea.getBoard();
    if (board[x][y] != null) {
      System.out.println(board[x][y] + " is in that choosen cell");
      return false;
    }
    board[x][y] = shape;
    return true;
  }

  public boolean clearBoard() {
    Shapes[][] board = playArea.getBoard();
    for (int i = 0; i < board.length; i++) {
      for (int j = 0; j < board[0].length; j++) {
        board[i][j] = null;
      }
    }
    return true;
  }

  public boolean checkForWinner(int x, int y, Shapes s) {
    Shapes[][] board = playArea.getBoard();
    boolean rowCheck = true;
    boolean colCheck = true;
    boolean leftDiagonalCheck = true;
    boolean rightDiagonalCheck = true;
    int k = 1;
    for (int j = 0; j < board[0].length; j++) {
      if (board[x][j] != s) {
        rowCheck = false;
        break;
      }
    }
    for (int i = 0; i < board.length; i++) {
      if (board[i][y] != s) {
        colCheck = false;
        break;
      }
    }
    if (x + y == board.length - 1) {
      for (int i = 0, j = 0; i < board.length && j < board[0].length; i++, j++) {
        if (board[i][j] != s) {
          rightDiagonalCheck = false;
          break;
        }
      }
      for (int i = board.length - 1, j = 0; i >= 0 && j < board[0].length; i--, j++) {
        if (board[i][j] != s) {
          leftDiagonalCheck = false;
          break;
        }
      }
    }
    return rowCheck || colCheck || leftDiagonalCheck || rightDiagonalCheck;
  }
}