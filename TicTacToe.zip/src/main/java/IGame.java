public interface IGame {
  void startGame() throws Exception;

  void endGame();

  void initialize() throws Exception;

  boolean createPlayer(int id, String name, Shapes playerShape) throws Exception;

  void setPlayersSize(int size);
}