import java.util.*;

public class Game implements IGame {
  private TicTacToeController ticTacToeController;
  private Queue<Player> playersList = new LinkedList<Player>();
  private int playersSize;

  public Game(TicTacToeController ticTacToeController) {
    this.ticTacToeController = ticTacToeController;
  }

  public boolean createPlayer(int id, String name, Shapes playerShape) throws Exception {
    Player p = new Player(id, name, playerShape);
    if (playersSize < playersList.size()) {
      throw new Exception("players size Exceeded");
    }
    playersList.add(p);
    return true;
  }

  public void initialize() throws Exception {
    ticTacToeController.createBoard(3, 3);
    System.out.println("Board Created");
    this.createPlayer(1, "sunny", Shapes.X);
    this.createPlayer(2, "Shalini", Shapes.O);
    if (playersList.size() > playersSize)
      throw new Exception("size exceeded");
    System.out.println("Players created");
  }

  public void setPlayersSize(int size) {
    this.playersSize = size;
  }

  public void startGame() throws Exception {
    System.out.println("Game Started");
    initialize();
    boolean winner = false;
    while (!winner) {
      ticTacToeController.displayBoard();
      Player p = playersList.poll();
      System.out.println("Player " + p.getName() + " is playing");
      System.out.println("choose position : ");
      Scanner sc = new Scanner(System.in);
      boolean choosed = false;
      int x = -1;
      int y = -1;
      while (!choosed) {
        x = Integer.parseInt(sc.nextLine());
        y = Integer.parseInt(sc.nextLine());
        choosed = ticTacToeController.chooseShape(x, y, p.getPlayerShape());
      }
      winner = ticTacToeController.checkForWinner(x, y, p.getPlayerShape());
      if (winner) {
        System.out.println("Player Won : " + p.getName());
        break;
      }
      if (ticTacToeController.isBoardFull()) {
        System.out.println("Tie Match");
        break;
      }
      playersList.add(p);
    }
    endGame();
  }

  public void endGame() {
    ticTacToeController.clearBoard();
    System.out.println("Game Ended !");
  }
}