public class TicTacToePlayArea {
  private Shapes[][] board;

  public TicTacToePlayArea(Shapes[][] board) {
    this.board = board;
  }

  public TicTacToePlayArea() {
  }

  public Shapes getCellShape(int x, int y) {
    return board[x][y];
  }

  public void setCellShape(int x, int y, Shapes s) {
    this.board[x][y] = s;
  }

  public Shapes[][] getBoard() {
    return board;
  }

  public void setBoard(Shapes[][] board) {
    this.board = board;
  }
}