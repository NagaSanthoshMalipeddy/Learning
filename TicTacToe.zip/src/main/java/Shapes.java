public enum Shapes {
  X,
  O
}