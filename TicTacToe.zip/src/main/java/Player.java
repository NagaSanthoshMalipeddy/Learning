public class Player {
  public int id;
  public String name;
  public Shapes playerShape;

  public Player(int id, String name, Shapes playerShape) {
    this.id = id;
    this.name = name;
    this.playerShape = playerShape;
  }

  public Player() {
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Shapes getPlayerShape() {
    return playerShape;
  }

  public void setPlayerShape(Shapes playerShape) {
    this.playerShape = playerShape;
  }

}