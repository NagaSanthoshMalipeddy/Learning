import java.util.*;

public interface IShoppingCart {
  public List<Product> getProducts();

  public void removeProductFromCart(int name);

  public void addProductToCart(Product product);

  public int getTotalPrice();
}