public class CartSingleton {
  public static IShoppingCart c;

  public static IShoppingCart getCart() {
    if (c == null) {
      return new ShoppingCart();
    }
    return c;
  }
}