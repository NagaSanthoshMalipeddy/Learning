// import static org.junit.jupiter.api.Assertions.assertEquals;

// import org.junit.jupiter.api.Test;

public class Main {
  public static void main(String[] args) {
    IShoppingCart cart = CartSingleton.getCart();
    cart.addProductToCart(new FlatDiscountCoupon(12476, "FLAT75",
        new PercentageCoupon(13487, "10%Offer", new MartAProduct(1, "Milk", ProductType.Food, 400)), 75));
    cart.addProductToCart(new FlatDiscountCoupon(12477, "FLAT100",
        new PercentageCoupon(13488, "10%Offer", new MartAProduct(2, "Milk", ProductType.Food, 400)), 105));
    cart.addProductToCart(new FlatDiscountCoupon(12478, "FLAT25",
        new PercentageCoupon(13489, "10%Offer", new MartAProduct(3, "Milk", ProductType.Food, 400)), 25));
    System.out.println();
    cart.getProducts();
    System.out.println();
    cart.removeProductFromCart(12476);
    System.out.println();
    cart.getProducts();
    System.out.println();
    System.out.println(cart.getTotalPrice() + " is total price");
  }

  // @Test
  // void addition() {
  // assertEquals(2, 1 + 1);
  // }
}