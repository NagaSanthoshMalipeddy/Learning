public enum ProductType {
  Electronic,
  Furniture,
  Food,
  Beverages,
  Others
}