import java.util.*;

public class ShoppingCart implements IShoppingCart {
  private List<Product> products;

  public ShoppingCart() {
    this.products = new ArrayList<Product>();
  }

  public List<Product> getProducts() {
    for (Product p : products) {
      System.out.println("id : " + p.id + " Type : " + p.pType + " Name : " + p.name + " Price : " + p.getPrice());
    }
    return null;
  }

  public void removeProductFromCart(int id) {
    int ind = -1;
    int k = -1;
    for (Product p : products) {
      k++;
      if (p.id == id) {
        ind = k;
      }
    }
    products.remove(ind);
  }

  public void addProductToCart(Product product) {
    products.add(product);
    System.out.println("Added Successfully");
  }

  public int getTotalPrice() {
    int price = 0;
    for (Product p : products) {
      price += p.getPrice();
    }
    return price;
  }

  public void payment() {
    System.out.println("Payment successfull");
    clearCart();
  }

  public void clearCart() {
    products.clear();
  }

}