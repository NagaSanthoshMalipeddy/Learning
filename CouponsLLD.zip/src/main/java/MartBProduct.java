public class MartBProduct extends Product {

  public MartBProduct(int id, String name, ProductType pType, int price) {
    super(id, name, pType, price);
  }

}