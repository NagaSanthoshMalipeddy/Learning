public class PercentageCoupon extends Coupons{

	public PercentageCoupon(int id, String name, Product p) {
		super(id, name, p);
	}

  public int getPrice(){
    return p.getPrice()-(p.getPrice()*10/100);
  }
  
}