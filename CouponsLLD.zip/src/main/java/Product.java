public abstract class Product {
  int id;
  String name;
  ProductType pType;
  int price;

  public Product(int id, String name, ProductType pType, int price) {
    this.id = id;
    this.name = name;
    this.pType = pType;
    this.price = price;
  }

  public Product(int id, String name) {
    this.id = id;
    this.name = name;
  }

  public int getPrice() {
    return price;
  }
}