public class MartAProduct extends Product{

	public MartAProduct(int id, String name, ProductType pType, int price) {
		super(id, name, pType, price);
	}
  
}