public class FlatDiscountCoupon extends Coupons {
  int discount;

  public FlatDiscountCoupon(int id, String name, Product p, int discount) {
    super(id, name, p);
    this.discount = discount;
  }

  public int getPrice() {
    return p.getPrice() - discount;
  }
}