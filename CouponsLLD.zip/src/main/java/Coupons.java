public class Coupons extends Product{
  int id;
  String name;
  Product p;
  public Coupons(int id,String name,Product p){
    super(id,name);
    this.p=p;
  }
}