public interface IProduct {
  public void getName();
}