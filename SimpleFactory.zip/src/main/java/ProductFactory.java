public class ProductFactory {
  public static IProduct getProduct(String param) {
    if (param.equalsIgnoreCase("phone")) {
      return new Phone();
    } else if (param.equalsIgnoreCase("laptop")) {
      return new Laptop();
    } else {
      return new AC();
    }
  }
}