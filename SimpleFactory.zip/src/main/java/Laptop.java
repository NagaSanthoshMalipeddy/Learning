public class Laptop implements IProduct {
  public void getName() {
    System.out.println("Laptop");
  }
}