public class AC implements IProduct {
  public void getName() {
    System.out.println("AC");
  }
}