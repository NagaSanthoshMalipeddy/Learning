public class Phone implements IProduct {
  public void getName() {
    System.out.println("Phone");
  }
}